import axios from 'axios';

const API_BASE_URL = 'http://localhost:5000';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add token to requests
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Handle 401 errors (unauthorized)
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('userRole');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export const authAPI = {
  register: (name, email, password) =>
    api.post('/register', { name, email, password }),

  login: (email, password) =>
    api.post('/login', { email, password }),
};

export const userAPI = {
  getUserInfo: () =>
    api.get('/api/user_info'),
};

export const maintenanceAPI = {
  createRequest: (description) =>
    api.post('/api/maintenance', { description }),

  getRequests: () =>
    api.get('/api/maintenance'),
};

export const noticeAPI = {
  getNotices: () =>
    api.get('/api/notices'),

  postNotice: (title, content) =>
    api.post('/api/admin/notices', { title, content }),
};

export const adminAPI = {
  assignApartment: (userEmail, unitNumber) =>
    api.post('/api/admin/assign_apartment', { user_email: userEmail, unit_number: unitNumber }),

  getVacantApartments: () =>
    api.get('/api/apartments/vacant'),
};

export default api;

