from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from flask_cors import CORS
from flask_jwt_extended import create_access_token
from flask_jwt_extended import get_jwt_identity
from flask_jwt_extended import jwt_required
from flask_jwt_extended import JWTManager
import os # Added for environment variable access (best practice)

# --- App Setup ---
app = Flask(__name__)
CORS(app) # Enables cross-origin requests for frontend development

# --- Config & Database Setup ---
# Use an environment variable for the secret key, with a fallback
app.config["JWT_SECRET_KEY"] = os.getenv("JWT_SECRET_KEY", "my-super-secret-key-that-is-not-secret")
jwt = JWTManager(app)

# Use SQLite for development
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///bms_data.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)


# --- Database Models ---

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(20), default='resident') # 'admin' or 'resident'

    # Relationship back to the Apartment this user resides in
    apartment = db.relationship('Apartment', backref='resident', uselist=False, lazy=True)
    requests = db.relationship('MaintenanceRequest', backref='author', lazy=True)


class Building(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    address = db.Column(db.String(200), nullable=False)
    apartments = db.relationship('Apartment', backref='building', lazy=True)


class Apartment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    unit_number = db.Column(db.String(20), nullable=False, unique=True)
    floor = db.Column(db.Integer)
    bedrooms = db.Column(db.Integer)
    building_id = db.Column(db.Integer, db.ForeignKey('building.id'), nullable=False)
    # Link to the User (Resident)
    resident_id = db.Column(db.Integer, db.ForeignKey('user.id'), unique=True, nullable=True)
    requests = db.relationship('MaintenanceRequest', backref='apartment', lazy=True)


class MaintenanceRequest(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    description = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(50), nullable=False, default='Pending')
    created_at = db.Column(db.DateTime, server_default=db.func.now())
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    apartment_id = db.Column(db.Integer, db.ForeignKey('apartment.id'), nullable=False)


class NoticeBoard(db.Model): # NEW Model for public announcements
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150), nullable=False)
    content = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, server_default=db.func.now())


# --- Utility Functions ---

def is_admin():
    """Checks if the user identified by the JWT token has 'admin' role."""
    user_identity = get_jwt_identity()
    # Handle both dict (new format) and string (old format) for backward compatibility
    if isinstance(user_identity, dict):
        user_email = user_identity['email']
    else:
        user_email = user_identity
    user = User.query.filter_by(email=user_email).first()
    return user and user.role == 'admin'


# --- General Auth Routes ---

@app.route('/register', methods=['POST'])
def register():
    data = request.json
    full_name = data.get('name')
    email = data.get('email')
    password = data.get('password')

    if not all([full_name, email, password]):
        return jsonify({"status": "error", "message": "All fields are required"}), 400

    if User.query.filter_by(email=email).first():
        return jsonify({"status": "error", "message": "Email already registered"}), 409

    try:
        new_user = User(
            full_name=full_name,
            email=email.lower(),
            password_hash=generate_password_hash(password),
            role='resident' # Default role for new registrations
        )
        db.session.add(new_user)
        db.session.commit()
        return jsonify({"status": "success", "message": "Registration successful. Please wait for apartment assignment."}), 201
    except Exception as e:
        db.session.rollback()
        print("Registration error:", e)
        return jsonify({"status": "error", "message": "Registration failed"}), 500


@app.route('/login', methods=['POST'])
def login():
    data = request.json
    email = data.get('email').lower()
    password = data.get('password')

    user = User.query.filter_by(email=email).first()

    if user and check_password_hash(user.password_hash, password):
        # Identity includes role for quick frontend checks
        access_token = create_access_token(identity={'email': user.email, 'role': user.role})
        return jsonify({"status": "success", "token": access_token, "role": user.role})

    return jsonify({"status": "error", "message": "Invalid credentials"}), 401


# --- API Routes (General User) ---

@app.route("/api/user_info", methods=['GET'])
@jwt_required()
def get_user_info():
    user_identity = get_jwt_identity()
    user_email = user_identity['email']
    user = User.query.filter_by(email=user_email).first()

    if not user:
        return jsonify({"status": "error", "message": "User not found"}), 404

    # Get apartment details if assigned
    apartment_info = None
    if user.apartment:
        apartment_info = {
            "unit_number": user.apartment.unit_number,
            "floor": user.apartment.floor,
            "building": user.apartment.building.name
        }

    return jsonify({
        "status": "success",
        "full_name": user.full_name,
        "email": user.email,
        "role": user.role,
        "apartment": apartment_info
    }), 200


@app.route("/api/maintenance", methods=['POST'])
@jwt_required()
def create_maintenance_request():
    user_identity = get_jwt_identity()
    user = User.query.filter_by(email=user_identity['email']).first()

    apartment = Apartment.query.filter_by(resident_id=user.id).first()
    if not apartment:
        return jsonify({"status": "error", "message": "You must be assigned to an apartment to submit a request"}), 400

    data = request.json
    description = data.get('description')
    if not description:
        return jsonify({"status": "error", "message": "Description is required"}), 400

    new_request = MaintenanceRequest(
        description=description,
        user_id=user.id,
        apartment_id=apartment.id,
        status="Pending"
    )
    db.session.add(new_request)
    db.session.commit()

    return jsonify({"status": "success", "message": "Maintenance request submitted"}), 201


@app.route("/api/maintenance", methods=['GET'])
@jwt_required()
def get_maintenance_requests():
    user_identity = get_jwt_identity()
    user = User.query.filter_by(email=user_identity['email']).first()

    requests = MaintenanceRequest.query.filter_by(user_id=user.id).order_by(MaintenanceRequest.created_at.desc()).all()

    request_list = []
    for req in requests:
        request_list.append({
            "id": req.id,
            "apartment": req.apartment.unit_number,
            "description": req.description,
            "status": req.status,
            "created_at": req.created_at.strftime("%Y-%m-%d %H:%M")
        })

    return jsonify({"status": "success", "requests": request_list}), 200


@app.route("/api/notices", methods=['GET'])
@jwt_required()
def get_notices():
    notices = NoticeBoard.query.order_by(NoticeBoard.created_at.desc()).all()

    notice_list = []
    for notice in notices:
        notice_list.append({
            "id": notice.id,
            "title": notice.title,
            "content": notice.content,
            "date_posted": notice.created_at.strftime("%Y-%m-%d %H:%M")
        })

    return jsonify({"status": "success", "notices": notice_list}), 200


# --- API Routes (Admin Only) ---

@app.route("/api/admin/assign_apartment", methods=['POST'])
@jwt_required()
def assign_apartment():
    if not is_admin():
        return jsonify({"status": "error", "message": "Admin privileges required"}), 403

    data = request.json
    user_email = data.get('user_email').lower()
    unit_number = data.get('unit_number').upper()

    user = User.query.filter_by(email=user_email).first()
    apartment = Apartment.query.filter_by(unit_number=unit_number).first()

    if not user:
        return jsonify({"status": "error", "message": "User not found"}), 404
    if not apartment:
        return jsonify({"status": "error", "message": f"Apartment {unit_number} not found"}), 404
    if apartment.resident_id is not None:
        return jsonify({"status": "error", "message": f"Apartment {unit_number} is already occupied"}), 409
    if Apartment.query.filter_by(resident_id=user.id).first():
        return jsonify({"status": "error", "message": f"User {user_email} is already assigned to a unit"}), 409

    apartment.resident_id = user.id
    db.session.commit()
    return jsonify({"status": "success", "message": f"User {user_email} assigned to {unit_number}"}), 200


@app.route("/api/admin/notices", methods=['POST'])
@jwt_required()
def post_notice():
    if not is_admin():
        return jsonify({"status": "error", "message": "Admin privileges required"}), 403

    data = request.json
    title = data.get('title')
    content = data.get('content')

    if not title or not content:
        return jsonify({"status": "error", "message": "Title and content are required"}), 400

    new_notice = NoticeBoard(title=title, content=content)
    db.session.add(new_notice)
    db.session.commit()

    return jsonify({"status": "success", "message": f"Notice '{title}' posted"}), 201


@app.route("/api/apartments/vacant", methods=['GET'])
@jwt_required()
def get_vacant_apartments():
    # Admin or Resident can view available units
    vacant_apts = Apartment.query.filter_by(resident_id=None).all()

    apt_list = [{
        "unit_number": apt.unit_number,
        "floor": apt.floor,
        "bedrooms": apt.bedrooms
    } for apt in vacant_apts]

    return jsonify({"status": "success", "vacant_apartments": apt_list}), 200

# --- Main Execution ---
if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        print("Database tables checked/created.")

        # --- Initial Setup Logic ---
        if not Building.query.first():
            print("No building found. Creating default building and flats...")

            # 1. Create Default Building
            default_building = Building(name="BMS Tower", address="123 Main St")
            db.session.add(default_building)
            db.session.commit()

            # 2. Create Default Apartments (e.g., 3 floors, 2 units/floor)
            flats_list = [f"{floor}{chr(ord('A') + i)}" for floor in range(1, 4) for i in range(2)]
            for flat in flats_list:
                floor = int(flat[0])
                new_apt = Apartment(
                    unit_number=flat,
                    floor=floor,
                    bedrooms=2,
                    building_id=default_building.id
                )
                db.session.add(new_apt)

            # 3. Create Default Admin User
            if not User.query.filter_by(email="admin@bms.com").first():
                admin_user = User(
                    full_name="BMS Administrator",
                    email="admin@bms.com",
                    password_hash=generate_password_hash("supersecure")
                )
                db.session.add(admin_user)
                print("Default Admin User created: admin@bms.com / supersecure")

            db.session.commit()
            print("Initial setup complete.")

    app.run(port=5000, debug=True)
