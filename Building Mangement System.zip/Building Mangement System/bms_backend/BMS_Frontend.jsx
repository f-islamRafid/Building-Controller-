import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { LogIn, LogOut, LayoutDashboard, User, Bell, Home, Hammer, ListChecks, Users, Plus } from 'lucide-react';

// --- CONFIGURATION ---
const API_BASE_URL = 'http://127.0.0.1:5000';

// --- API FUNCTIONS ---

// Function to handle fetching and ensure we include the Authorization header
const apiFetch = async (endpoint, options = {}) => {
    const token = localStorage.getItem('token');
    const headers = {
        'Content-Type': 'application/json',
        ...options.headers,
    };

    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }

    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        ...options,
        headers,
    });

    if (response.status === 401) {
        // Token expired or invalid
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.reload(); 
    }

    // Attempt to parse JSON response
    const data = await response.json();
    return { response, data };
};

// --- COMPONENTS ---

// Global Application State Context
const AuthContext = React.createContext();

// Hook to manage global authentication state and user data
const useAuth = () => {
    const [user, setUser] = useState(JSON.parse(localStorage.getItem('user')) || null);
    const [token, setToken] = useState(localStorage.getItem('token') || null);
    const [isLoading, setIsLoading] = useState(true);

    // Logs user in, stores data, and sets tokens
    const login = useCallback(async (email, password) => {
        try {
            const { response, data } = await apiFetch('/login', {
                method: 'POST',
                body: JSON.stringify({ email, password }),
                headers: { 'Content-Type': 'application/json' },
            });

            if (response.ok) {
                localStorage.setItem('token', data.token);
                setToken(data.token);
                // Fetch user info immediately after login to populate context
                await fetchUserInfo(data.token);
                return { success: true };
            } else {
                return { success: false, message: data.message || 'Login failed.' };
            }
        } catch (error) {
            console.error('Login error:', error);
            return { success: false, message: 'API connection error.' };
        }
    }, []);

    // Logs user out and clears local storage
    const logout = useCallback(() => {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        setToken(null);
        setUser(null);
    }, []);

    // Fetches user details and updates the user state
    const fetchUserInfo = useCallback(async (tokenOverride) => {
        const currentToken = tokenOverride || token;
        if (!currentToken) {
            setIsLoading(false);
            return;
        }

        try {
            const { response, data } = await apiFetch('/api/user_info', {
                method: 'GET',
                headers: { 'Authorization': `Bearer ${currentToken}` }
            });

            if (response.ok && data.status === 'success') {
                localStorage.setItem('user', JSON.stringify(data));
                setUser(data);
            } else {
                logout(); // Log out if token is invalid during info fetch
            }
        } catch (error) {
            console.error('User info fetch error:', error);
            logout();
        } finally {
            setIsLoading(false);
        }
    }, [token, logout]);

    // Effect to run on initial load to check token and fetch user info
    useEffect(() => {
        fetchUserInfo();
    }, [fetchUserInfo]);

    const contextValue = useMemo(() => ({
        user,
        token,
        isLoading,
        login,
        logout,
        fetchUserInfo // Expose to allow re-fetching data after updates
    }), [user, token, isLoading, login, logout, fetchUserInfo]);

    return contextValue;
};


// 1. Navigation Component
const NavItem = ({ icon: Icon, title, onClick, currentView }) => (
    <button
        onClick={onClick}
        className={`flex items-center space-x-3 p-3 text-sm font-medium rounded-lg transition-colors duration-200 w-full text-left
            ${currentView === title.toLowerCase().replace(/\s/g, '_') 
                ? 'bg-indigo-700 text-white shadow-lg' 
                : 'text-indigo-200 hover:bg-indigo-700 hover:text-white'
            }`}
    >
        <Icon className="w-5 h-5" />
        <span>{title}</span>
    </button>
);

// 2. Auth Form Component (Login/Register)
const AuthForm = ({ onToggleView, type }) => {
    const { login } = useAuth();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [name, setName] = useState('');
    const [message, setMessage] = useState('');
    const [loading, setLoading] = useState(false);

    const isLogin = type === 'login';

    const handleSubmit = async (e) => {
        e.preventDefault();
        setMessage('');
        setLoading(true);

        const payload = { email, password };
        if (!isLogin) payload.name = name;

        try {
            const endpoint = isLogin ? '/login' : '/register';
            const { response, data } = await apiFetch(endpoint, {
                method: 'POST',
                body: JSON.stringify(payload),
                headers: { 'Content-Type': 'application/json' },
            });

            if (response.ok) {
                if (isLogin) {
                    await login(email, password);
                } else {
                    setMessage('Registration successful! Please login.');
                    onToggleView('login');
                }
            } else {
                setMessage(data.message || 'An unexpected error occurred.');
            }
        } catch (error) {
            setMessage('Network error or API unreachable.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="w-full max-w-md bg-white p-8 rounded-xl shadow-2xl">
            <h2 className="text-3xl font-bold text-gray-800 mb-6 text-center">
                {isLogin ? 'Welcome Back' : 'Create Account'}
            </h2>
            <form onSubmit={handleSubmit} className="space-y-4">
                {!isLogin && (
                    <input
                        type="text"
                        placeholder="Full Name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        required={!isLogin}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
                    />
                )}
                <input
                    type="email"
                    placeholder="Email Address"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
                />
                <input
                    type="password"
                    placeholder="Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
                />
                <button
                    type="submit"
                    disabled={loading}
                    className="w-full py-3 px-4 bg-indigo-600 text-white font-semibold rounded-lg shadow-md hover:bg-indigo-700 transition duration-300 disabled:opacity-50 flex items-center justify-center"
                >
                    {loading ? (
                        <svg className="animate-spin h-5 w-5 mr-3 text-white" viewBox="0 0 24 24">...</svg>
                    ) : isLogin ? 'Log In' : 'Register'}
                </button>
            </form>
            {message && (
                <p className={`mt-4 text-center text-sm ${message.includes('successful') ? 'text-green-600' : 'text-red-500'}`}>
                    {message}
                </p>
            )}
            <div className="mt-6 text-center text-sm">
                {isLogin ? (
                    <p>Don't have an account? <button onClick={() => onToggleView('register')} className="text-indigo-600 hover:underline font-medium">Register</button></p>
                ) : (
                    <p>Already have an account? <button onClick={() => onToggleView('login')} className="text-indigo-600 hover:underline font-medium">Log In</button></p>
                )}
            </div>
        </div>
    );
};


// 3. User Info/Profile View
const UserProfile = () => {
    const { user } = useAuth();
    if (!user) return null;

    return (
        <div className="space-y-6">
            <h3 className="text-2xl font-semibold border-b pb-2 text-gray-700">My Profile</h3>
            <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100">
                <div className="space-y-3">
                    <p className="flex justify-between items-center text-gray-600">
                        <span className="font-medium">Full Name:</span>
                        <span className="font-bold text-gray-800">{user.full_name}</span>
                    </p>
                    <p className="flex justify-between items-center text-gray-600">
                        <span className="font-medium">Email:</span>
                        <span className="text-sm">{user.email}</span>
                    </p>
                    <p className="flex justify-between items-center text-gray-600">
                        <span className="font-medium">Role:</span>
                        <span className={`px-3 py-1 text-xs font-semibold rounded-full ${user.role === 'admin' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}`}>
                            {user.role.toUpperCase()}
                        </span>
                    </p>
                </div>
            </div>

            {user.apartment ? (
                <div className="bg-indigo-50 p-6 rounded-xl shadow-lg border border-indigo-200">
                    <h4 className="text-lg font-semibold text-indigo-700 mb-3 flex items-center"><Home className="w-5 h-5 mr-2" /> Residence Details</h4>
                    <p className="flex justify-between items-center text-gray-700">
                        <span className="font-medium">Unit Number:</span>
                        <span className="text-xl font-extrabold text-indigo-900">{user.apartment.unit_number}</span>
                    </p>
                    <p className="flex justify-between items-center text-gray-700">
                        <span className="font-medium">Floor:</span>
                        <span>{user.apartment.floor}</span>
                    </p>
                    <p className="flex justify-between items-center text-gray-700">
                        <span className="font-medium">Building:</span>
                        <span>{user.apartment.building}</span>
                    </p>
                </div>
            ) : (
                <div className="bg-yellow-50 p-4 rounded-lg text-yellow-800 border border-yellow-200">
                    <p className="font-medium">Status: Awaiting Apartment Assignment.</p>
                    <p className="text-sm">Please contact the Administration to be assigned to a unit.</p>
                </div>
            )}
        </div>
    );
};


// 4. Resident Maintenance View
const ResidentMaintenance = () => {
    const [requests, setRequests] = useState([]);
    const [description, setDescription] = useState('');
    const [loading, setLoading] = useState(false);
    const [message, setMessage] = useState('');

    const fetchRequests = useCallback(async () => {
        try {
            const { response, data } = await apiFetch('/api/maintenance', { method: 'GET' });
            if (response.ok && data.status === 'success') {
                setRequests(data.requests);
            }
        } catch (error) {
            console.error('Error fetching requests:', error);
        }
    }, []);

    useEffect(() => {
        fetchRequests();
    }, [fetchRequests]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setMessage('');
        setLoading(true);

        try {
            const { response, data } = await apiFetch('/api/maintenance', {
                method: 'POST',
                body: JSON.stringify({ description }),
            });

            if (response.ok) {
                setMessage('Request submitted successfully!');
                setDescription('');
                fetchRequests();
            } else {
                setMessage(data.message || 'Failed to submit request.');
            }
        } catch (error) {
            setMessage('API connection error.');
        } finally {
            setLoading(false);
        }
    };

    const getStatusClass = (status) => {
        switch (status) {
            case 'Pending': return 'bg-yellow-100 text-yellow-800';
            case 'In Progress': return 'bg-blue-100 text-blue-800';
            case 'Completed': return 'bg-green-100 text-green-800';
            default: return 'bg-gray-100 text-gray-800';
        }
    };

    return (
        <div className="space-y-6">
            <h3 className="text-2xl font-semibold border-b pb-2 text-gray-700">Maintenance Requests</h3>
            
            <div className="bg-white p-6 rounded-xl shadow-lg">
                <h4 className="text-xl font-medium text-indigo-700 mb-4 flex items-center"><Hammer className="w-5 h-5 mr-2"/> Submit New Request</h4>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <textarea
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        placeholder="Describe the issue (e.g., leaky faucet in bathroom, A/C not cooling)."
                        rows="4"
                        required
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 resize-none"
                    />
                    <button
                        type="submit"
                        disabled={loading || !description.trim()}
                        className="py-2 px-4 bg-indigo-600 text-white font-semibold rounded-lg shadow-md hover:bg-indigo-700 transition duration-300 disabled:opacity-50"
                    >
                        {loading ? 'Submitting...' : 'Submit Request'}
                    </button>
                    {message && (
                        <p className={`text-sm ${message.includes('success') ? 'text-green-600' : 'text-red-500'}`}>{message}</p>
                    )}
                </form>
            </div>

            <div className="space-y-4">
                <h4 className="text-xl font-medium text-gray-700 flex items-center"><ListChecks className="w-5 h-5 mr-2"/> My Submitted Requests</h4>
                {requests.length === 0 ? (
                    <p className="text-gray-500 bg-white p-4 rounded-lg">No maintenance requests submitted yet.</p>
                ) : (
                    requests.map((req) => (
                        <div key={req.id} className="bg-white p-4 rounded-lg shadow-md border-l-4 border-indigo-400">
                            <div className="flex justify-between items-center mb-2">
                                <span className="text-sm font-medium text-gray-500">{req.created_at}</span>
                                <span className={`px-3 py-1 text-xs font-semibold rounded-full ${getStatusClass(req.status)}`}>
                                    {req.status}
                                </span>
                            </div>
                            <p className="text-gray-800">{req.description}</p>
                            <p className="text-xs text-gray-400 mt-1">Unit: {req.apartment}</p>
                        </div>
                    ))
                )}
            </div>
        </div>
    );
};


// 5. Notices View (Shared)
const NoticesView = () => {
    const [notices, setNotices] = useState([]);
    const [loading, setLoading] = useState(true);

    const fetchNotices = useCallback(async () => {
        setLoading(true);
        try {
            const { response, data } = await apiFetch('/api/notices', { method: 'GET' });
            if (response.ok && data.status === 'success') {
                setNotices(data.notices);
            }
        } catch (error) {
            console.error('Error fetching notices:', error);
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchNotices();
    }, [fetchNotices]);

    return (
        <div className="space-y-6">
            <h3 className="text-2xl font-semibold border-b pb-2 text-gray-700 flex items-center"><Bell className="w-6 h-6 mr-2"/> Building Notices</h3>
            {loading ? (
                <p className="text-center text-gray-500">Loading notices...</p>
            ) : notices.length === 0 ? (
                <p className="text-center text-gray-500 bg-white p-4 rounded-lg shadow">No notices have been posted yet.</p>
            ) : (
                <div className="grid md:grid-cols-2 gap-4">
                    {notices.map((notice) => (
                        <div key={notice.id} className="bg-white p-6 rounded-xl shadow-lg border-t-4 border-indigo-500 transition hover:shadow-xl">
                            <h4 className="text-xl font-bold text-gray-800 mb-2">{notice.title}</h4>
                            <p className="text-sm text-gray-500 mb-3">Posted: {notice.date_posted}</p>
                            <p className="text-gray-700">{notice.content}</p>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};


// 6. Admin Management View (Assign Users & Post Notice)
const AdminManagement = () => {
    const { fetchUserInfo } = useAuth();
    const [vacantFlats, setVacantFlats] = useState([]);
    const [users, setUsers] = useState([]); // In a real app, you'd fetch all users
    const [message, setMessage] = useState({ text: '', type: '' });
    const [loading, setLoading] = useState(false);
    
    // Form states for assignment
    const [selectedUserEmail, setSelectedUserEmail] = useState('');
    const [selectedFlat, setSelectedFlat] = useState('');
    
    // Form states for notice
    const [noticeTitle, setNoticeTitle] = useState('');
    const [noticeContent, setNoticeContent] = useState('');

    // Fetch vacant flats and users (simplified: using registered users)
    const fetchManagementData = useCallback(async () => {
        try {
            // Fetch vacant flats
            const { response: flatResponse, data: flatData } = await apiFetch('/api/apartments/vacant', { method: 'GET' });
            if (flatResponse.ok) setVacantFlats(flatData.vacant_apartments);

            // Fetch users (Note: This assumes we have a dedicated admin endpoint to fetch ALL users, 
            // but since we don't, we simulate the "registered users" state for assignment)
            // In a production environment, you would need an /api/admin/users endpoint.
        } catch (error) {
            console.error('Error fetching admin data:', error);
        }
    }, []);

    useEffect(() => {
        fetchManagementData();
        // Since we don't have an /api/admin/users endpoint, we will display a mock list
        setUsers([
            { email: 'alice@tenant.com', name: 'Alice Resident' },
            { email: 'bob@tenant.com', name: 'Bob Newbie' }
        ]);
    }, [fetchManagementData]);
    
    // Handle Apartment Assignment
    const handleAssign = async (e) => {
        e.preventDefault();
        setMessage({ text: '', type: '' });
        setLoading(true);

        try {
            const { response, data } = await apiFetch('/api/admin/assign_apartment', {
                method: 'POST',
                body: JSON.stringify({ user_email: selectedUserEmail, unit_number: selectedFlat }),
            });

            if (response.ok) {
                setMessage({ text: data.message, type: 'success' });
                setSelectedUserEmail('');
                setSelectedFlat('');
                fetchManagementData(); // Refresh vacant flats list
                fetchUserInfo(); // Refresh admin's own info just in case
            } else {
                setMessage({ text: data.message || 'Assignment failed.', type: 'error' });
            }
        } catch (error) {
            setMessage({ text: 'API connection error.', type: 'error' });
        } finally {
            setLoading(false);
        }
    };
    
    // Handle Notice Posting
    const handlePostNotice = async (e) => {
        e.preventDefault();
        setMessage({ text: '', type: '' });
        setLoading(true);

        try {
            const { response, data } = await apiFetch('/api/admin/notices', {
                method: 'POST',
                body: JSON.stringify({ title: noticeTitle, content: noticeContent }),
            });

            if (response.ok) {
                setMessage({ text: data.message, type: 'success' });
                setNoticeTitle('');
                setNoticeContent('');
            } else {
                setMessage({ text: data.message || 'Failed to post notice.', type: 'error' });
            }
        } catch (error) {
            setMessage({ text: 'API connection error.', type: 'error' });
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="space-y-8">
            <h3 className="text-2xl font-semibold border-b pb-2 text-gray-700">Administrative Tools</h3>
            
            {/* Assignment Section */}
            <div className="bg-white p-6 rounded-xl shadow-lg border border-indigo-100">
                <h4 className="text-xl font-medium text-indigo-700 mb-4 flex items-center"><Users className="w-5 h-5 mr-2"/> Assign Resident to Apartment</h4>
                <form onSubmit={handleAssign} className="space-y-4">
                    <select
                        value={selectedUserEmail}
                        onChange={(e) => setSelectedUserEmail(e.target.value)}
                        required
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
                    >
                        <option value="">Select Resident (Email)</option>
                        {/* Note: This list is static. In a real app, it would be dynamic users not yet assigned a flat */}
                        {users.map(user => (
                            <option key={user.email} value={user.email}>{user.name} ({user.email})</option>
                        ))}
                    </select>
                    <select
                        value={selectedFlat}
                        onChange={(e) => setSelectedFlat(e.target.value)}
                        required
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
                    >
                        <option value="">Select Vacant Flat</option>
                        {vacantFlats.map(flat => (
                            <option key={flat.unit_number} value={flat.unit_number}>
                                {flat.unit_number} (Floor {flat.floor}, {flat.bedrooms} BR)
                            </option>
                        ))}
                    </select>
                    <button
                        type="submit"
                        disabled={loading || !selectedUserEmail || !selectedFlat}
                        className="py-2 px-4 bg-green-600 text-white font-semibold rounded-lg shadow-md hover:bg-green-700 transition duration-300 disabled:opacity-50"
                    >
                        {loading ? 'Assigning...' : 'Assign Apartment'}
                    </button>
                    {message.type === 'success' && message.text && <p className="text-sm text-green-600">{message.text}</p>}
                    {message.type === 'error' && message.text && <p className="text-sm text-red-500">{message.text}</p>}
                </form>
            </div>

            {/* Notice Posting Section */}
            <div className="bg-white p-6 rounded-xl shadow-lg border border-red-100">
                <h4 className="text-xl font-medium text-red-700 mb-4 flex items-center"><Plus className="w-5 h-5 mr-2"/> Post New Building Notice</h4>
                <form onSubmit={handlePostNotice} className="space-y-4">
                    <input
                        type="text"
                        placeholder="Notice Title"
                        value={noticeTitle}
                        onChange={(e) => setNoticeTitle(e.target.value)}
                        required
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-red-500 focus:border-red-500"
                    />
                    <textarea
                        value={noticeContent}
                        onChange={(e) => setNoticeContent(e.target.value)}
                        placeholder="Notice Content (e.g., Water Shutoff Notice)"
                        rows="4"
                        required
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-red-500 focus:border-red-500 resize-none"
                    />
                    <button
                        type="submit"
                        disabled={loading || !noticeTitle.trim() || !noticeContent.trim()}
                        className="py-2 px-4 bg-red-600 text-white font-semibold rounded-lg shadow-md hover:bg-red-700 transition duration-300 disabled:opacity-50"
                    >
                        {loading ? 'Posting...' : 'Post Notice'}
                    </button>
                </form>
            </div>
        </div>
    );
};


// 7. Main Dashboard Layout
const Dashboard = () => {
    const { user, logout } = useAuth();
    const [currentView, setCurrentView] = useState('user_profile');

    const role = user?.role || 'resident';

    // Set initial view based on role
    useEffect(() => {
        if (role === 'admin') {
            setCurrentView('admin_management');
        } else {
            setCurrentView('user_profile');
        }
    }, [role]);


    const renderContent = () => {
        switch (currentView) {
            case 'user_profile':
                return <UserProfile />;
            case 'maintenance':
                return <ResidentMaintenance />;
            case 'notices':
                return <NoticesView />;
            case 'admin_management':
                return <AdminManagement />;
            default:
                return <UserProfile />;
        }
    };

    const navItems = [
        { title: 'User Profile', icon: User, view: 'user_profile' },
        { title: 'Notices', icon: Bell, view: 'notices' },
    ];
    
    // Add role-specific items
    if (role === 'resident') {
        navItems.splice(1, 0, { title: 'Maintenance', icon: Hammer, view: 'maintenance' });
    } else if (role === 'admin') {
        navItems.splice(1, 0, { title: 'Admin Management', icon: LayoutDashboard, view: 'admin_management' });
    }

    return (
        <div className="flex h-screen bg-gray-50 font-sans">
            {/* Sidebar */}
            <div className="w-64 bg-indigo-800 text-white flex flex-col p-4 shadow-xl">
                <div className="text-2xl font-bold mb-8 flex items-center space-x-2">
                    <Home className="w-6 h-6"/>
                    <span>BMS Portal</span>
                </div>
                <div className="flex-grow space-y-2">
                    {navItems.map((item) => (
                        <NavItem 
                            key={item.view} 
                            title={item.title} 
                            icon={item.icon} 
                            onClick={() => setCurrentView(item.view)}
                            currentView={currentView}
                        />
                    ))}
                </div>
                <div className="mt-8 pt-4 border-t border-indigo-700">
                    <div className="text-sm font-medium mb-3">Logged in as: {user.full_name} ({user.role})</div>
                    <button
                        onClick={logout}
                        className="flex items-center space-x-3 p-3 text-sm font-medium rounded-lg transition-colors duration-200 w-full text-left text-indigo-200 hover:bg-red-700 hover:text-white"
                    >
                        <LogOut className="w-5 h-5" />
                        <span>Logout</span>
                    </button>
                </div>
            </div>

            {/* Main Content */}
            <main className="flex-1 overflow-y-auto p-8">
                <header className="mb-8 pb-4 border-b border-gray-200">
                    <h1 className="text-4xl font-extrabold text-gray-900">
                        {navItems.find(item => item.view === currentView)?.title || 'Dashboard'}
                    </h1>
                    <p className="text-sm text-gray-500 mt-1">Welcome to {role === 'admin' ? 'the Administration Interface' : user.apartment ? user.apartment.unit_number : 'your Tenant Portal'}.</p>
                </header>
                {renderContent()}
            </main>
        </div>
    );
};


// 8. Root Application Component
export default function App() {
    const auth = useAuth();
    const [authView, setAuthView] = useState('login'); // 'login' or 'register'

    if (auth.isLoading) {
        return (
            <div className="h-screen flex items-center justify-center bg-gray-100">
                <div className="text-indigo-600 flex items-center text-lg font-medium">
                    <svg className="animate-spin h-6 w-6 mr-3 text-indigo-500" viewBox="0 0 24 24">...</svg>
                    Connecting to BMS API...
                </div>
            </div>
        );
    }

    if (!auth.token || !auth.user) {
        return (
            <div className="h-screen flex items-center justify-center bg-gray-100 p-4">
                <AuthForm onToggleView={setAuthView} type={authView} />
            </div>
        );
    }

    return (
        <AuthContext.Provider value={auth}>
            <Dashboard />
        </AuthContext.Provider>
    );
}